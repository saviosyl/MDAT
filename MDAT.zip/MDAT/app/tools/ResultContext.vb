Public Module ResultContext
    Public ToolName As String = ""
    Public ResultText As String = ""
End Module
