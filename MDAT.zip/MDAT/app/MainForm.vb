Option Strict On
Option Explicit On

Imports System
Imports System.IO
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Collections.Generic
Imports System.Runtime.InteropServices
Imports System.Reflection
Imports System.Globalization
Imports System.Net
Imports System.Threading

Public Class MainForm
    Inherits Form

    '========================================================
    ' APP
    '========================================================
    Private Const APP_NAME As String = "MDAT – Mechanical Design Automation Tool"
    Private Const CONFIG_FILE As String = "config.txt"

    Private Const EXPIRY_WARNING_DAYS As Integer = 30
    Private Const EXPIRY_CRITICAL_DAYS As Integer = 7

    ' Persisted timing stats (per slot)
    Private Const ACTION_TIMES_FILE As String = "action_times.txt"

    '========================================================
    ' TELEMETRY CONFIG (ADDITIVE)
    '========================================================
    Private syncUrl As String = ""
    Private telemetryToken As String = ""
    Private telemetryEnabled As Boolean = True ' default ON unless TELEMETRY=OFF

    '========================================================
    ' MACRO DELIVERY (R2 via Worker) - ADDITIVE
    '========================================================
    Private macroDeliveryUrl As String = ""
    Private macroToken As String = ""
    Private macroCacheDir As String = "" ' default computed
    Private hideMacroCache As Boolean = True

    ' Option C: auto-clean cache after each successful run
    Private autoCleanMacroCacheAfterSuccess As Boolean = True

    ' Cleanup retry (handles "file in use" from SolidWorks)
    Private cleanupTimer As System.Windows.Forms.Timer = Nothing
    Private cleanupRetryCount As Integer = 0
    Private Const CLEANUP_MAX_RETRIES As Integer = 30 ' ~60 sec if interval=2000ms

    '========================================================
    ' SELECTED ASSEMBLY
    '========================================================
    Private selectedAssemblyPath As String = String.Empty

    '========================================================
    ' SOLIDWORKS OBJECTS (late-binding)
    '========================================================
    Private swApp As Object = Nothing
    Private swModel As Object = Nothing

    '========================================================
    ' UI STATE
    '========================================================
    Private selectedButton As Button = Nothing

    '========================================================
    ' HEADER CONTROLS
    '========================================================
    Private pnlHeader As Panel
    Private pnlHeaderLine As Panel
    Private picLogo As PictureBox
    Private lblTitle As Label
    Private lblSubtitle As Label
    Private btnTheme As Button
    Private btnLicense As Button
    Private lblVersion As Label
    Private lblLicence As Label
    Private lblValidity As Label

    '========================================================
    ' CENTRE
    '========================================================
    Private cmbSW As ComboBox
    Private btnSelectFile As Button
    Private txtLog As TextBox

    '========================================================
    ' FOOTER
    '========================================================
    Private lblFooter As Label

    '========================================================
    ' SIDE PANELS
    '========================================================
    Private pnlDesign As Panel
    Private pnlEngineering As Panel
    Private pnlDesignContent As Panel
    Private pnlEngineeringContent As Panel

    '========================================================
    ' MACROS
    '========================================================
    Private macroDisplayMap As New Dictionary(Of Integer, String)()
    Private macroExecMap As New Dictionary(Of Integer, String)()

    '========================================================
    ' LICENSE STATE
    '========================================================
    Private activeLicense As LicenseInfo = Nothing
    Private currentTier As Integer = 0
    Private licenseValid As Boolean = False

    '========================================================
    ' THEME
    '========================================================
    Private Enum ThemeMode
        PANEL_LIGHT
        PANEL_DARK
        PANEL_MM
        PANEL_CUSTOM
    End Enum

    Private currentTheme As ThemeMode = ThemeMode.PANEL_LIGHT
    Private customAccent As Color = Color.FromArgb(115, 60, 190)

    Private BG_LIGHT As Color = Color.FromArgb(245, 246, 248)
    Private PANEL_LIGHT As Color = Color.FromArgb(230, 232, 235)

    Private BG_DARK As Color = Color.FromArgb(26, 30, 36)
    Private PANEL_DARK As Color = Color.FromArgb(38, 42, 50)

    Private BG_MM As Color = Color.FromArgb(242, 240, 248)
    Private PANEL_MM As Color = Color.FromArgb(225, 220, 240)

    Private currentThemeIsDark As Boolean = False

    '========================================================
    ' ACTION TIMING
    '========================================================
    Private Class ActionStat
        Public Count As Integer
        Public AvgSeconds As Double
    End Class

    Private actionStart As New Dictionary(Of Integer, DateTime)()
    Private actionStats As New Dictionary(Of Integer, ActionStat)()

    '========================================================
    ' INIT
    '========================================================
    Public Sub New()
        Try
            Me.Text = APP_NAME
            Me.StartPosition = FormStartPosition.CenterScreen
            Me.Font = New Font("Segoe UI", 10)
            Me.FormBorderStyle = FormBorderStyle.Sizable
            Me.MinimumSize = New Size(1000, 650)

            Dim wa As Rectangle = Screen.PrimaryScreen.WorkingArea
            Me.Size = New Size(CInt(wa.Width * 0.9), CInt(wa.Height * 0.85))

            BuildHeader()
            BuildCentre()
            BuildSidePanels()
            BuildFooter()

            LoadMacrosFromConfig()
            LoadActionStats()

            ' ---- LICENSE LOAD ----
            Try
                activeLicense = Licensing.GetLicenseInfo()
                ResolveTierFromLicense(activeLicense)
            Catch
                licenseValid = False
            End Try

            ' ---- SEAT + TELEMETRY + MACRO DELIVERY CONFIG ----
            Try
                LoadSeatConfigFromConfig()
            Catch
            End Try

            ' Ensure cache folder exists early (best-effort)
            Try
                EnsureMacroCacheFolder()
            Catch
            End Try

            ' ---- TELEMETRY FLUSH ----
            Try
                If telemetryEnabled AndAlso syncUrl <> "" AndAlso telemetryToken <> "" Then
                    TelemetryQueue.Flush(syncUrl, telemetryToken, 8000)
                End If
            Catch
            End Try

            BuildButtons()
            ApplyTierLocks()
            ApplyTheme()

            LogA("✅", "Application ready.")
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "MDAT Startup Failure", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            Application.[Exit]()
        End Try
    End Sub

    '========================================================
    ' FORCE FIRST LAYOUT (OLD UI BEHAVIOUR)
    '========================================================
    Protected Overrides Sub OnShown(e As EventArgs)
        MyBase.OnShown(e)
        HeaderResize(Nothing, EventArgs.Empty)
    End Sub

    '========================================================
    ' HEADER (OLD UI FROM MainForm - old.txt)
    '========================================================
    Private Sub BuildHeader()
        pnlHeader = New Panel() With {
            .Dock = DockStyle.Top,
            .Height = 90,
            .BackColor = PANEL_LIGHT
        }
        Me.Controls.Add(pnlHeader)

        picLogo = New PictureBox() With {
            .Size = New Size(160, 70),
            .Location = New Point(20, 10),
            .SizeMode = PictureBoxSizeMode.Zoom,
            .BackColor = Color.Transparent
        }
        pnlHeader.Controls.Add(picLogo)

        Dim logoPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets\logo\logo.png")
        Try
            If File.Exists(logoPath) Then
                Using fs As New FileStream(logoPath, FileMode.Open, FileAccess.Read)
                    Using bmp As New Bitmap(fs)
                        picLogo.Image = New Bitmap(bmp)
                    End Using
                End Using
            End If
        Catch
        End Try

        lblTitle = New Label() With {
            .Text = "MetaMech Mechanical Design Automation",
            .Font = New Font("Segoe UI", 18, FontStyle.Bold),
            .AutoSize = True,
            .Location = New Point(picLogo.Right + 15, 20)
        }
        pnlHeader.Controls.Add(lblTitle)

        lblSubtitle = New Label() With {
            .Text = "Designed by MetaMech Solutions",
            .Font = New Font("Segoe UI", 9, FontStyle.Italic),
            .AutoSize = True,
            .Location = New Point(picLogo.Right + 15, 55)
        }
        pnlHeader.Controls.Add(lblSubtitle)

        btnTheme = New Button() With {.Text = "THEME ▾", .Size = New Size(90, 28)}
        AddHandler btnTheme.Click, AddressOf ShowThemeMenu
        pnlHeader.Controls.Add(btnTheme)

        btnLicense = New Button() With {.Text = "LICENSE ▾", .Size = New Size(90, 28)}
        AddHandler btnLicense.Click, AddressOf ShowLicensePopup
        pnlHeader.Controls.Add(btnLicense)

        lblLicence = New Label() With {
            .Font = New Font("Segoe UI", 9, FontStyle.Bold),
            .AutoSize = True
        }
        pnlHeader.Controls.Add(lblLicence)

        lblValidity = New Label() With {
            .Font = New Font("Segoe UI", 8),
            .AutoSize = True
        }
        pnlHeader.Controls.Add(lblValidity)

        AddHandler pnlHeader.Resize, AddressOf HeaderResize

        pnlHeaderLine = New Panel() With {
            .Dock = DockStyle.Top,
            .Height = 2,
            .BackColor = customAccent
        }
        Me.Controls.Add(pnlHeaderLine)
    End Sub

    Private Sub HeaderResize(sender As Object, e As EventArgs)
        If pnlHeader Is Nothing Then Return

        btnTheme.Location = New Point(pnlHeader.Width - 110, 15)
        btnLicense.Location = New Point(pnlHeader.Width - 210, 15)

        lblLicence.Location = New Point(pnlHeader.Width - 260, 50)
        lblValidity.Location = New Point(pnlHeader.Width - 260, 68)
    End Sub

    '========================================================
    ' CENTRE (OLD UI FROM MainForm - old.txt)
    '========================================================
    Private Sub BuildCentre()
        cmbSW = New ComboBox() With {
            .DropDownStyle = ComboBoxStyle.DropDownList,
            .Location = New Point(250, 105)
        }
        cmbSW.Items.AddRange(New String() {"2022", "2023", "2024", "2025"})
        cmbSW.SelectedIndex = 0
        Me.Controls.Add(cmbSW)

        btnSelectFile = New Button() With {
            .Text = "Select Assembly (.SLDASM)",
            .Size = New Size(260, 35),
            .Location = New Point(400, 100)
        }
        AddHandler btnSelectFile.Click, AddressOf SelectAssembly
        Me.Controls.Add(btnSelectFile)

        ' NOTE: widened right panel means we must slightly reduce log width (keeps it visible, no overlap)
        txtLog = New TextBox() With {
            .Multiline = True,
            .ReadOnly = True,
            .ScrollBars = ScrollBars.Vertical,
            .Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right,
            .Location = New Point(250, 150),
            .Size = New Size(Me.ClientSize.Width - 620, Me.ClientSize.Height - 220)
        }
        Me.Controls.Add(txtLog)
    End Sub

    '========================================================
    ' SIDE PANELS (OLD UI FROM MainForm - old.txt)
    '========================================================
    Private Sub BuildSidePanels()
        pnlDesign = New Panel() With {
            .Width = 210,
            .Location = New Point(20, 150),
            .Height = Me.ClientSize.Height - 220,
            .BorderStyle = BorderStyle.FixedSingle,
            .Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        }
        Me.Controls.Add(pnlDesign)

        pnlDesign.Controls.Add(New Label() With {
            .Text = "DESIGN TOOLS",
            .Dock = DockStyle.Top,
            .Height = 32,
            .Font = New Font("Segoe UI", 10, FontStyle.Bold),
            .TextAlign = ContentAlignment.MiddleCenter
        })

        pnlDesignContent = New Panel() With {.Dock = DockStyle.Fill, .AutoScroll = True}
        pnlDesign.Controls.Add(pnlDesignContent)

        ' FIX: Make engineering tools panel wider so full button text fits (requested)
        pnlEngineering = New Panel() With {
            .Width = 300,
            .Location = New Point(Me.ClientSize.Width - 320, 150),
            .Height = Me.ClientSize.Height - 220,
            .BorderStyle = BorderStyle.FixedSingle,
            .Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Right
        }
        Me.Controls.Add(pnlEngineering)

        pnlEngineering.Controls.Add(New Label() With {
            .Text = "ENGINEERING TOOLS",
            .Dock = DockStyle.Top,
            .Height = 32,
            .Font = New Font("Segoe UI", 10, FontStyle.Bold),
            .TextAlign = ContentAlignment.MiddleCenter
        })

        pnlEngineeringContent = New Panel() With {.Dock = DockStyle.Fill, .AutoScroll = True}
        pnlEngineering.Controls.Add(pnlEngineeringContent)
    End Sub

    '========================================================
    ' FOOTER (OLD UI FROM MainForm - old.txt)
    '========================================================
    Private Sub BuildFooter()
        lblFooter = New Label() With {
            .Text = "Registered Name: John Byrne Conveyors & Packaging Services Ltd. T/A CPS",
            .Font = New Font("Segoe UI", 8, FontStyle.Italic),
            .AutoSize = True,
            .Anchor = AnchorStyles.Bottom Or AnchorStyles.Left,
            .Location = New Point(250, Me.ClientSize.Height - 28)
        }
        Me.Controls.Add(lblFooter)
    End Sub

    '========================================================
    ' ASSEMBLY SELECTION
    '========================================================
    Private Sub SelectAssembly(sender As Object, e As EventArgs)
        Using ofd As New OpenFileDialog()
            ofd.Title = "Select Top-Level Assembly"
            ofd.Filter = "SolidWorks Assembly (*.sldasm)|*.sldasm"
            ofd.Multiselect = False

            If ofd.ShowDialog() <> DialogResult.OK Then Exit Sub

            selectedAssemblyPath = ofd.FileName
            LogA("📁", "Assembly selected:")
            LogA("🔗", selectedAssemblyPath)
        End Using
    End Sub

    Private Function IsAssemblySelected() As Boolean
        Return Not String.IsNullOrEmpty(selectedAssemblyPath)
    End Function

    '========================================================
    ' SOLIDWORKS BOOTSTRAP
    '========================================================
    Private Function EnsureSolidWorksRunning() As Boolean
        Dim year As String = "2022"
        Try
            If cmbSW IsNot Nothing AndAlso cmbSW.SelectedItem IsNot Nothing Then
                year = cmbSW.SelectedItem.ToString().Trim()
            End If
        Catch
        End Try

        Dim suffix As String = GetSWProgIDSuffix(year)
        Dim progId As String = "SldWorks.Application." & suffix

        If swApp IsNot Nothing Then
            If IsComObjectAlive(swApp) Then
                Return True
            Else
                swApp = Nothing
            End If
        End If

        Try
            swApp = Marshal.GetActiveObject(progId)
            If swApp IsNot Nothing Then
                LogA("🧷", "Attached to SolidWorks " & year & " (" & progId & ").")
                TrySetSwVisible(swApp, True)
                Return True
            End If
        Catch
            swApp = Nothing
        End Try

        Try
            swApp = CreateObject(progId)
            If swApp Is Nothing Then
                LogA("❌", "Failed to create SolidWorks instance: " & progId)
                Return False
            End If

            TrySetSwVisible(swApp, True)
            LogA("✅", "SolidWorks " & year & " started successfully (" & progId & ").")
            Return True

        Catch ex As Exception
            LogA("❌", "Failed to start SolidWorks " & year & ": " & ex.Message)
            swApp = Nothing
            Return False
        End Try
    End Function

    Private Function IsComObjectAlive(comObj As Object) As Boolean
        Try
            Dim v As Object = comObj.GetType().InvokeMember( _
                "Visible", _
                BindingFlags.GetProperty Or BindingFlags.Public Or BindingFlags.Instance, _
                Nothing, _
                comObj, _
                Nothing _
            )
            Return True
        Catch
            Return False
        End Try
    End Function

    Private Sub TrySetSwVisible(appObj As Object, isVisible As Boolean)
        Try
            appObj.GetType().InvokeMember( _
                "Visible", _
                BindingFlags.SetProperty Or BindingFlags.Public Or BindingFlags.Instance, _
                Nothing, _
                appObj, _
                New Object() {isVisible} _
            )
        Catch
        End Try
    End Sub

    '========================================================
    ' OPEN OR REUSE ASSEMBLY (OpenDoc)
    '========================================================
    Private Function EnsureAssemblyOpen() As Boolean
        If swApp Is Nothing Then
            LogA("❌", "SolidWorks not available.")
            Return False
        End If

        If String.IsNullOrEmpty(selectedAssemblyPath) OrElse Not File.Exists(selectedAssemblyPath) Then
            LogA("❌", "Selected assembly path invalid.")
            Return False
        End If

        Try
            Dim existing As Object = Nothing
            Try
                existing = swApp.GetType().InvokeMember( _
                    "GetOpenDocumentByName", _
                    BindingFlags.InvokeMethod Or BindingFlags.Public Or BindingFlags.Instance, _
                    Nothing, _
                    swApp, _
                    New Object() {CStr(selectedAssemblyPath)} _
                )
            Catch
                existing = Nothing
            End Try

            If existing IsNot Nothing Then
                swModel = existing
                LogA("📌", "Assembly already open.")
            Else
                Dim opened As Object = Nothing
                Try
                    opened = swApp.GetType().InvokeMember( _
                        "OpenDoc", _
                        BindingFlags.InvokeMethod Or BindingFlags.Public Or BindingFlags.Instance, _
                        Nothing, _
                        swApp, _
                        New Object() {CStr(selectedAssemblyPath), CInt(2)} _
                    )
                Catch ex As Exception
                    If ex.InnerException IsNot Nothing Then
                        LogA("❌", "OpenDoc inner error: " & ex.InnerException.Message)
                    End If
                    LogA("❌", "OpenDoc error: " & ex.Message)
                    opened = Nothing
                End Try

                If opened Is Nothing Then
                    LogA("❌", "Failed to open assembly. (OpenDoc returned Nothing)")
                    swModel = Nothing
                    Return False
                End If

                swModel = opened
                LogA("✅", "Assembly opened successfully (OpenDoc).")
            End If

            Try
                swApp.GetType().InvokeMember( _
                    "ActivateDoc3", _
                    BindingFlags.InvokeMethod Or BindingFlags.Public Or BindingFlags.Instance, _
                    Nothing, _
                    swApp, _
                    New Object() {Path.GetFileName(selectedAssemblyPath), False, 0, 0} _
                )
            Catch
            End Try

            Try
                CallByName(swModel, "ResolveAllLightWeightComponents", CallType.Method, True)
                LogA("🧩", "Resolved lightweight components.")
            Catch
            End Try

            Try
                CallByName(swModel, "ForceRebuild3", CallType.Method, False)
            Catch
            End Try

            Return True

        Catch ex As Exception
            If ex.InnerException IsNot Nothing Then
                LogA("❌", "SolidWorks inner error: " & ex.InnerException.Message)
            End If
            LogA("❌", "SolidWorks error: " & ex.Message)
            swModel = Nothing
            Return False
        End Try
    End Function

    '========================================================
    ' RUN ACTION (macro) FROM CONFIG
    '========================================================
    Private Function RunMacroSlot(slot As Integer) As Boolean
        If Not macroExecMap.ContainsKey(slot) Then
            LogA("⚠️", "No tool configured for slot " & slot.ToString() & ".")
            Return False
        End If

        Dim execRaw As String = macroExecMap(slot)
        Dim parts() As String = execRaw.Split("|"c)

        If parts.Length < 3 Then
            LogA("❌", "Invalid tool config for slot " & slot.ToString() & ": " & execRaw)
            Return False
        End If

        Dim swpPath As String = parts(0).Trim()
        Dim moduleName As String = parts(1).Trim()
        Dim procName As String = parts(2).Trim()

        Dim toolName As String = ""
        If macroDisplayMap.ContainsKey(slot) Then
            toolName = macroDisplayMap(slot)
        Else
            toolName = Path.GetFileNameWithoutExtension(swpPath)
        End If

        ' ---- AUTO FETCH MACRO (R2 delivery) ----
        If (String.IsNullOrEmpty(swpPath) OrElse Not File.Exists(swpPath)) Then
            Dim cachedPath As String = ""
            If EnsureMacroAvailable(swpPath, cachedPath) Then
                swpPath = cachedPath
                macroExecMap(slot) = swpPath & "|" & moduleName & "|" & procName
            End If
        End If

        LogActionStart(slot, toolName, swpPath, moduleName & "." & procName)

        ' ---- TELEMETRY START ----
        Dim teleStartUtc As DateTime = DateTime.UtcNow
        Dim asmName As String = GetAssemblyNameSafe()
        SendTelemetrySafe("START", slot, toolName, 0, "ASM=" & asmName)

        If String.IsNullOrEmpty(swpPath) OrElse Not File.Exists(swpPath) Then
            LogA("❌", "Tool file not found: " & swpPath)
            LogActionEnd(slot, False, "Failed")
            SendTelemetrySafe("FAIL", slot, toolName, CInt((DateTime.UtcNow - teleStartUtc).TotalMilliseconds), "ASM=" & asmName & " | Missing tool file")
            Return False
        End If

        If swApp Is Nothing Then
            LogA("❌", "SolidWorks not available.")
            LogActionEnd(slot, False, "Failed")
            SendTelemetrySafe("FAIL", slot, toolName, CInt((DateTime.UtcNow - teleStartUtc).TotalMilliseconds), "ASM=" & asmName & " | SolidWorks not available")
            Return False
        End If

        Dim ok As Boolean = False
        Dim detail As String = ""

        ' Try RunMacro2 first
        ok = InvokeRunMacro2(swpPath, moduleName, procName, detail)
        If ok Then
            LogActionEnd(slot, True, "✅ Completed")
            SendTelemetrySafe("END", slot, toolName, CInt((DateTime.UtcNow - teleStartUtc).TotalMilliseconds), "ASM=" & asmName & " | Completed (RunMacro2)")
            LogA("🎉", "Successful — Thanks for using MetaMech Design Automation Tool")

            If autoCleanMacroCacheAfterSuccess Then StartMacroCacheCleanupRetrySilent()
            Return True
        Else
            If detail <> "" Then LogA("⚠️", "RunMacro2: " & detail)
        End If

        ' Fallback RunMacro
        detail = ""
        ok = InvokeRunMacro(swpPath, moduleName, procName, detail)
        If ok Then
            LogActionEnd(slot, True, "✅ Completed")
            SendTelemetrySafe("END", slot, toolName, CInt((DateTime.UtcNow - teleStartUtc).TotalMilliseconds), "ASM=" & asmName & " | Completed (fallback)")
            LogA("🎉", "Successful — Thanks for using MetaMech Design Automation Tool")

            If autoCleanMacroCacheAfterSuccess Then StartMacroCacheCleanupRetrySilent()
            Return True
        Else
            If detail <> "" Then LogA("⚠️", "RunMacro: " & detail)
        End If

        LogActionEnd(slot, False, "Failed")
        SendTelemetrySafe("FAIL", slot, toolName, CInt((DateTime.UtcNow - teleStartUtc).TotalMilliseconds), "ASM=" & asmName & " | Failed")
        Return False
    End Function

    '========================================================
    ' RunMacro2 / RunMacro
    '========================================================
    Private Function InvokeRunMacro2(macroPath As String, moduleName As String, procName As String, ByRef detail As String) As Boolean
        detail = ""
        Dim args5(4) As Object
        args5(0) = CStr(macroPath)
        args5(1) = CStr(moduleName)
        args5(2) = CStr(procName)
        args5(3) = CInt(0)
        args5(4) = CInt(0)

        Try
            Dim result As Object = swApp.GetType().InvokeMember( _
                "RunMacro2", _
                BindingFlags.InvokeMethod Or BindingFlags.Public Or BindingFlags.Instance, _
                Nothing, _
                swApp, _
                args5 _
            )
            Return MacroResultIsSuccess(result, detail)
        Catch ex As Exception
            detail = "Exception: " & ex.Message
            Return False
        End Try
    End Function

    Private Function InvokeRunMacro(macroPath As String, moduleName As String, procName As String, ByRef detail As String) As Boolean
        detail = ""
        Dim args3(2) As Object
        args3(0) = CStr(macroPath)
        args3(1) = CStr(moduleName)
        args3(2) = CStr(procName)

        Try
            Dim result As Object = swApp.GetType().InvokeMember( _
                "RunMacro", _
                BindingFlags.InvokeMethod Or BindingFlags.Public Or BindingFlags.Instance, _
                Nothing, _
                swApp, _
                args3 _
            )
            Return MacroResultIsSuccess(result, detail)
        Catch ex As Exception
            detail = "Exception: " & ex.Message
            Return False
        End Try
    End Function

    Private Function MacroResultIsSuccess(v As Object, ByRef detail As String) As Boolean
        detail = ""

        If v Is Nothing Then
            detail = "Returned Nothing"
            Return False
        End If

        Try
            If TypeOf v Is Integer Then
                Dim code As Integer = CInt(v)
                detail = "Code=" & code.ToString()
                Return (code = 0)
            End If
            If TypeOf v Is Long Then
                Dim code As Long = CLng(v)
                detail = "Code=" & code.ToString()
                Return (code = 0L)
            End If
            If TypeOf v Is Short Then
                Dim code As Short = CShort(v)
                detail = "Code=" & code.ToString()
                Return (code = 0S)
            End If

            If TypeOf v Is Boolean Then
                Dim b As Boolean = CBool(v)
                detail = "Bool=" & If(b, "True", "False")
                Return b
            End If

            Dim s As String = Convert.ToString(v)
            If s IsNot Nothing Then
                s = s.Trim()
                Dim n As Integer = 0
                If Integer.TryParse(s, n) Then
                    detail = "Code=" & n.ToString()
                    Return (n = 0)
                End If
                Dim bb As Boolean = False
                If Boolean.TryParse(s, bb) Then
                    detail = "Bool=" & If(bb, "True", "False")
                    Return bb
                End If
            End If

            detail = "Unknown return type: " & v.GetType().FullName
            Return False

        Catch ex As Exception
            detail = "Parse error: " & ex.Message
            Return False
        End Try
    End Function

    '========================================================
    ' OPTION C – CLEANUP WITH RETRIES (SILENT)
    '========================================================
    Private Sub StartMacroCacheCleanupRetrySilent()
        Try
            Dim ok As Boolean = TryCleanMacroCacheOnce()
            If ok Then
                Return
            End If

            cleanupRetryCount = 0
            If cleanupTimer Is Nothing Then
                cleanupTimer = New System.Windows.Forms.Timer()
                cleanupTimer.Interval = 2000
                AddHandler cleanupTimer.Tick, AddressOf CleanupTimerTickSilent
            End If

            If Not cleanupTimer.Enabled Then
                cleanupTimer.Start()
            End If
        Catch
        End Try
    End Sub

    Private Sub CleanupTimerTickSilent(sender As Object, e As EventArgs)
        Try
            cleanupRetryCount += 1

            Dim ok As Boolean = TryCleanMacroCacheOnce()
            If ok Then
                Try
                    cleanupTimer.Stop()
                Catch
                End Try
                Return
            End If

            If cleanupRetryCount >= CLEANUP_MAX_RETRIES Then
                Try
                    cleanupTimer.Stop()
                Catch
                End Try
            End If
        Catch
        End Try
    End Sub

    Private Function TryCleanMacroCacheOnce() As Boolean
        Try
            If Not EnsureMacroCacheFolder() Then Return False
            If macroCacheDir Is Nothing OrElse macroCacheDir.Trim() = "" Then Return False

            If Not Directory.Exists(macroCacheDir) Then
                Return True
            End If

            Try
                File.SetAttributes(macroCacheDir, FileAttributes.Normal)
            Catch
            End Try

            Dim anyLocked As Boolean = False

            Dim files() As String = Nothing
            Try
                files = Directory.GetFiles(macroCacheDir, "*", SearchOption.AllDirectories)
            Catch
                files = Nothing
            End Try

            If files IsNot Nothing Then
                For Each f As String In files
                    Dim deleted As Boolean = False
                    For i As Integer = 1 To 6
                        Try
                            File.SetAttributes(f, FileAttributes.Normal)
                        Catch
                        End Try

                        Try
                            File.Delete(f)
                            deleted = True
                            Exit For
                        Catch
                            Try
                                Thread.Sleep(150)
                            Catch
                            End Try
                        End Try
                    Next

                    If Not deleted Then
                        anyLocked = True
                    End If
                Next
            End If

            Try
                RemoveEmptyDirsSafe(macroCacheDir)
            Catch
            End Try

            Try
                If Directory.Exists(macroCacheDir) Then
                    Dim hasFiles As Boolean = (Directory.GetFiles(macroCacheDir, "*", SearchOption.AllDirectories).Length > 0)
                    Dim hasDirs As Boolean = (Directory.GetDirectories(macroCacheDir, "*", SearchOption.AllDirectories).Length > 0)
                    If (Not hasFiles) AndAlso (Not hasDirs) Then
                        Directory.Delete(macroCacheDir, False)
                    End If
                End If
            Catch
                anyLocked = True
            End Try

            If hideMacroCache AndAlso Directory.Exists(macroCacheDir) Then
                Try
                    Dim attr As FileAttributes = File.GetAttributes(macroCacheDir)
                    If (attr And FileAttributes.Hidden) = 0 Then
                        File.SetAttributes(macroCacheDir, attr Or FileAttributes.Hidden)
                    End If
                Catch
                End Try
            End If

            Return Not anyLocked

        Catch
            Return False
        End Try
    End Function

    Private Sub RemoveEmptyDirsSafe(root As String)
        Try
            Dim dirs() As String = Directory.GetDirectories(root, "*", SearchOption.AllDirectories)
            If dirs Is Nothing Then Exit Sub

            Array.Sort(dirs)
            Array.Reverse(dirs)

            For Each d As String In dirs
                Try
                    If Directory.Exists(d) Then
                        Dim hasFiles As Boolean = (Directory.GetFiles(d).Length > 0)
                        Dim hasDirs As Boolean = (Directory.GetDirectories(d).Length > 0)
                        If (Not hasFiles) AndAlso (Not hasDirs) Then
                            Directory.Delete(d, False)
                        End If
                    End If
                Catch
                End Try
            Next
        Catch
        End Try
    End Sub

    '========================================================
    ' ACTION TIMING HELPERS
    '========================================================
    Private Sub LogActionStart(slot As Integer, toolName As String, toolPath As String, entryPoint As String)
        actionStart(slot) = DateTime.Now

        Log("")
        Log("🧩 ACTION START — Slot " & slot.ToString())
        LogA("🧾", "Tool: " & toolName)
        LogA("📄", "Script: " & toolPath)
        LogA("▶", "Running: " & entryPoint)

        Dim est As String = GetEstimatedTimeString(slot)
        If est <> "" Then
            LogA("⏱️", "Estimated: ~" & est & " (based on previous runs)")
        Else
            LogA("⏱️", "Estimated: learning… (will appear after first run)")
        End If
    End Sub

    Private Sub LogActionEnd(slot As Integer, success As Boolean, note As String)
        Dim elapsedSec As Double = 0
        If actionStart.ContainsKey(slot) Then
            elapsedSec = (DateTime.Now - actionStart(slot)).TotalSeconds
            actionStart.Remove(slot)
        End If

        If elapsedSec > 0 Then
            UpdateActionStats(slot, elapsedSec)
        End If

        Dim elapsedStr As String = FormatDuration(elapsedSec)

        If success Then
            Log(note)
            Log("✅ ACTION END — Slot " & slot.ToString() & " (" & elapsedStr & " elapsed)")
        Else
            LogA("❌", note)
            Log("❌ ACTION END — Slot " & slot.ToString() & " (" & elapsedStr & " elapsed)")
        End If

        Log("")
    End Sub

    Private Function GetEstimatedTimeString(slot As Integer) As String
        If actionStats.ContainsKey(slot) Then
            Dim st As ActionStat = actionStats(slot)
            If st IsNot Nothing AndAlso st.Count > 0 AndAlso st.AvgSeconds > 0 Then
                Return FormatDuration(st.AvgSeconds)
            End If
        End If
        Return ""
    End Function

    Private Sub UpdateActionStats(slot As Integer, lastSeconds As Double)
        If lastSeconds <= 0 Then Exit Sub

        Dim st As ActionStat = Nothing
        If actionStats.ContainsKey(slot) Then
            st = actionStats(slot)
        Else
            st = New ActionStat()
            st.Count = 0
            st.AvgSeconds = 0
            actionStats(slot) = st
        End If

        st.Count += 1
        If st.Count = 1 Then
            st.AvgSeconds = lastSeconds
        Else
            st.AvgSeconds = ((st.AvgSeconds * CDbl(st.Count - 1)) + lastSeconds) / CDbl(st.Count)
        End If

        SaveActionStats()
    End Sub

    Private Function FormatDuration(seconds As Double) As String
        If seconds < 0 Then seconds = 0
        Dim total As Integer = CInt(Math.Floor(seconds))
        Dim mins As Integer = total \ 60
        Dim secs As Integer = total Mod 60
        Return mins.ToString("00") & ":" & secs.ToString("00")
    End Function

    Private Sub LoadActionStats()
        Try
            actionStats.Clear()

            Dim p As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ACTION_TIMES_FILE)
            If Not File.Exists(p) Then Exit Sub

            Dim lines() As String = File.ReadAllLines(p)
            For Each line As String In lines
                Dim t As String = line.Trim()
                If t = "" OrElse t.StartsWith("#") Then Continue For

                Dim parts() As String = t.Split("|"c)
                If parts.Length < 3 Then Continue For

                Dim slot As Integer = 0
                Dim cnt As Integer = 0
                Dim avg As Double = 0

                If Not Integer.TryParse(parts(0).Trim(), slot) Then Continue For
                If Not Integer.TryParse(parts(1).Trim(), cnt) Then Continue For
                If Not Double.TryParse(parts(2).Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, avg) Then Continue For

                Dim st As New ActionStat()
                st.Count = Math.Max(0, cnt)
                st.AvgSeconds = Math.Max(0, avg)
                actionStats(slot) = st
            Next
        Catch
        End Try
    End Sub

    Private Sub SaveActionStats()
        Try
            Dim p As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ACTION_TIMES_FILE)

            Using sw As New StreamWriter(p, False)
                sw.WriteLine("# slot|count|avg_seconds")
                For Each kv As KeyValuePair(Of Integer, ActionStat) In actionStats
                    Dim slot As Integer = kv.Key
                    Dim st As ActionStat = kv.Value
                    If st Is Nothing Then Continue For
                    sw.WriteLine(slot.ToString() & "|" & st.Count.ToString() & "|" & st.AvgSeconds.ToString(CultureInfo.InvariantCulture))
                Next
            End Using
        Catch
        End Try
    End Sub

    '========================================================
    ' SolidWorks ProgID suffix mapping
    '========================================================
    Private Function GetSWProgIDSuffix(selectedYear As String) As String
        Select Case selectedYear
            Case "2022" : Return "30"
            Case "2023" : Return "31"
            Case "2024" : Return "32"
            Case "2025" : Return "33"
        End Select
        Return "30"
    End Function

    '========================================================
    ' BUTTON STYLE – LOCKED
    '========================================================
    Private Sub StyleDisabledButton(btn As Button)
        btn.Enabled = False
        btn.BackColor = Color.FromArgb(230, 230, 230)
        btn.ForeColor = Color.FromArgb(140, 140, 140)
        btn.FlatStyle = FlatStyle.Flat
        btn.FlatAppearance.BorderColor = Color.FromArgb(200, 200, 200)
        btn.FlatAppearance.BorderSize = 1
        btn.Cursor = Cursors.[Default]

        If Not btn.Text.StartsWith("🔒") Then
            btn.Text = "🔒 " & btn.Text
        End If

        Dim tip As New ToolTip()
        tip.SetToolTip(btn, "Locked — upgrade license to use this tool")
    End Sub

    '========================================================
    ' BUTTON BUILDER
    '========================================================
    Private Sub AddButton(parent As Panel, title As String, slot As Integer, y As Integer, clickHandler As EventHandler)
        Dim b As New Button()
        b.Text = title
        b.Tag = slot
        b.Name = "btnTool_" & slot.ToString()

        b.Location = New Point(18, y)
        b.Size = New Size(parent.Width - 36, 34)

        b.FlatStyle = FlatStyle.Flat
        b.FlatAppearance.BorderSize = 1
        b.FlatAppearance.BorderColor = Color.FromArgb(150, 90, 190)

        b.BackColor = Color.FromArgb(40, 45, 58)
        b.ForeColor = Color.White

        ' Slightly smaller font so long engineering tool names fit cleanly
        b.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)

        AddHandler b.Click, clickHandler
        parent.Controls.Add(b)
    End Sub

    '========================================================
    ' BUILD BUTTONS
    '========================================================
    Private Sub BuildButtons()
        pnlDesignContent.Controls.Clear()
        pnlEngineeringContent.Controls.Clear()

        Dim y As Integer = 60
        For i As Integer = 1 To 10
            If macroDisplayMap.ContainsKey(i) Then
                AddButton(pnlDesignContent, macroDisplayMap(i), i, y, AddressOf RunDesignTool)
                y += 40
            End If
        Next

        y = 60
        AddButton(pnlEngineeringContent, "CONVEYOR CALCULATOR", 11, y, AddressOf RunEngineeringTool)
        y += 40
        AddButton(pnlEngineeringContent, "PNEUMATIC CALCULATOR", 12, y, AddressOf RunEngineeringTool)
        y += 40
        AddButton(pnlEngineeringContent, "AIR CONSUMPTION & COMPRESSOR SIZING", 13, y, AddressOf RunEngineeringTool)
        y += 40
        AddButton(pnlEngineeringContent, "BEAM DEFLECTION & FRAME CHECK", 14, y, AddressOf RunEngineeringTool)
    End Sub

    '========================================================
    ' MACRO LOADER (supports [MACROS] section)
    '========================================================
    Private Sub LoadMacrosFromConfig()
        macroDisplayMap.Clear()
        macroExecMap.Clear()

        Dim cfgPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, CONFIG_FILE)
        If Not File.Exists(cfgPath) Then Return

        Dim inMacrosSection As Boolean = False

        For Each rawLine As String In File.ReadAllLines(cfgPath)
            Dim line As String = rawLine.Trim()
            If line = "" OrElse line.StartsWith("#") Then Continue For

            If line.StartsWith("[") AndAlso line.EndsWith("]") Then
                inMacrosSection = (line.Trim().ToUpperInvariant() = "[MACROS]")
                Continue For
            End If

            If HasMacrosSection(cfgPath) AndAlso Not inMacrosSection Then
                Continue For
            End If

            If Not line.Contains("=") Then Continue For

            Dim parts() As String = line.Split(New Char() {"="c}, 2)
            Dim slot As Integer
            If Not Integer.TryParse(parts(0).Trim(), slot) Then Continue For

            Dim execRaw As String = parts(1).Trim()

            Dim swpPath As String = execRaw
            If swpPath.Contains("|") Then swpPath = swpPath.Split("|"c)(0).Trim()
            If Not swpPath.ToLowerInvariant().EndsWith(".swp") Then Continue For

            macroExecMap(slot) = execRaw
            macroDisplayMap(slot) = Path.GetFileNameWithoutExtension(swpPath)
        Next
    End Sub

    Private Function HasMacrosSection(cfgPath As String) As Boolean
        Try
            Dim lines() As String = File.ReadAllLines(cfgPath)
            For Each l As String In lines
                If l IsNot Nothing Then
                    Dim t As String = l.Trim().ToUpperInvariant()
                    If t = "[MACROS]" Then Return True
                End If
            Next
        Catch
        End Try
        Return False
    End Function

    '========================================================
    ' TIER LOCKS
    '========================================================
    Private Sub ApplyTierLocks()
        For Each c As Control In pnlDesignContent.Controls
            Dim b As Button = TryCast(c, Button)
            If b Is Nothing Then Continue For
            If Not licenseValid OrElse Not TierLocks.CanRunDesignTool(CInt(b.Tag), currentTier) Then
                StyleDisabledButton(b)
            End If
        Next

        For Each c As Control In pnlEngineeringContent.Controls
            Dim b As Button = TryCast(c, Button)
            If b Is Nothing Then Continue For
            If Not licenseValid OrElse Not TierLocks.CanRunEngineeringTool(CInt(b.Tag), currentTier) Then
                StyleDisabledButton(b)
            End If
        Next
    End Sub

    '========================================================
    ' DESIGN TOOLS
    '========================================================
    Private Sub RunDesignTool(sender As Object, e As EventArgs)
        If Not IsAssemblySelected() Then
            LogA("⚠️", "Please select a Top-Level Assembly before running design tools.")
            Return
        End If

        If Not EnsureSeatForAction() Then
            Return
        End If

        Dim slot As Integer = 0
        Dim b As Button = TryCast(sender, Button)
        Try
            If b IsNot Nothing AndAlso b.Tag IsNot Nothing Then slot = CInt(b.Tag)
        Catch
            slot = 0
        End Try

        If slot <= 0 Then
            LogA("❌", "Invalid tool slot.")
            Return
        End If

        If Not EnsureSolidWorksRunning() Then Return
        If Not EnsureAssemblyOpen() Then Return

        RunMacroSlot(slot)
    End Sub

    '========================================================
    ' ENGINEERING TOOLS
    '========================================================
    Private Sub RunEngineeringTool(sender As Object, e As EventArgs)
        Dim slot As Integer = 0
        Dim b As Button = TryCast(sender, Button)

        Try
            If b IsNot Nothing AndAlso b.Tag IsNot Nothing Then
                slot = CInt(b.Tag)
            End If
        Catch
            slot = 0
        End Try

        If slot <= 0 Then
            LogA("❌", "Invalid engineering tool slot.")
            Return
        End If

        Dim frm As Form = Nothing
        Dim toolName As String = ""

        ' FIX: Proper Try/Catch/End Try (your build failed due to missing End Try)
        Try
            If slot = 11 Then
                toolName = "CONVEYOR CONFIGURATOR"
                frm = New ConveyorCalculatorForm()

            ElseIf slot = 12 Then
                toolName = "PNEUMATIC CYLINDER CALCULATOR"
                frm = New PneumaticCylinderCalculatorForm()

            ElseIf slot = 13 Then
                toolName = "AIR CONSUMPTION & COMPRESSOR SIZING"
                frm = New AirConsumptionForm()

            ElseIf slot = 14 Then
                toolName = "BEAM DEFLECTION & FRAME CHECK"
                MessageBox.Show("This tool is reserved (coming soon).", "Engineering Tool", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return

            Else
                LogA("⚠️", "Engineering tool not wired for slot " & slot.ToString() & ".")
                Return
            End If

        Catch ex As Exception
            LogA("❌", "Failed to create tool window: " & ex.Message)
            Return
        End Try

        If frm Is Nothing Then
            LogA("❌", "Tool window is Nothing.")
            Return
        End If

        Try
            ApplyThemeToToolForm(frm)
        Catch
        End Try

        Try
            Log("")
            Log("🧩 ACTION START — " & toolName)
            frm.Show(Me)
            frm.BringToFront()
            Log("✅ ACTION END — " & toolName & " (opened)")
            Log("")
        Catch ex As Exception
            LogA("❌", "Failed to show tool window: " & ex.Message)
        End Try
    End Sub

    Private Sub ApplyThemeToToolForm(frm As Form)
        If frm Is Nothing Then Exit Sub

        Dim bg As Color = BG_LIGHT
        Dim panel As Color = PANEL_LIGHT
        Dim isDark As Boolean = False

        Select Case currentTheme
            Case ThemeMode.PANEL_DARK
                bg = BG_DARK
                panel = PANEL_DARK
                isDark = True
            Case ThemeMode.PANEL_MM
                bg = BG_MM
                panel = PANEL_MM
                isDark = False
            Case ThemeMode.PANEL_CUSTOM
                bg = BG_LIGHT
                panel = PANEL_LIGHT
                isDark = False
            Case Else
                bg = BG_LIGHT
                panel = PANEL_LIGHT
                isDark = False
        End Select

        Try
            ThemeApplier.ApplyTheme(frm, bg, panel, customAccent, isDark)
        Catch
        End Try
    End Sub

    '========================================================
    ' LICENSE
    '========================================================
    Private Sub ResolveTierFromLicense(lic As LicenseInfo)
        licenseValid = False

        If lic Is Nothing OrElse Not lic.IsValid Then
            lblLicence.Text = "LICENCE: INVALID"
            lblLicence.ForeColor = Color.Red

            lblValidity.Text = "Please activate a valid license."
            lblValidity.ForeColor = Color.Red
            Return
        End If

        licenseValid = True
        currentTier = lic.Tier

        lblLicence.ForeColor = If(currentThemeIsDark, Color.White, Color.Black)
        lblLicence.Text = "LICENCE: ACTIVE"

        Dim tierName As String = GetTierNameSafe(lic.Tier)

        Dim seatsVal As Integer = -1
        Try
            seatsVal = lic.Seats
        Catch
            seatsVal = -1
        End Try

        Dim seatsShort As String
        If seatsVal >= 0 Then
            seatsShort = "S:" & seatsVal.ToString()
        Else
            seatsShort = "S:N/A"
        End If

        If lic.ExpiryUtc <= DateTime.UtcNow Then
            lblValidity.Text = tierName & " | " & seatsShort & " | ⛔ EXPIRED"
            lblValidity.ForeColor = Color.Red
            Return
        End If

        Dim daysLeft As Integer = CInt(Math.Floor((lic.ExpiryUtc - DateTime.UtcNow).TotalDays))
        If daysLeft < 0 Then daysLeft = 0

        If lic.Tier = 0 Then
            If daysLeft <= EXPIRY_CRITICAL_DAYS Then
                lblValidity.Text = "TRIAL | " & seatsShort & " | ⛔ ENDING IN " & daysLeft.ToString() & "D"
                lblValidity.ForeColor = Color.Red
            ElseIf daysLeft <= EXPIRY_WARNING_DAYS Then
                lblValidity.Text = "TRIAL | " & seatsShort & " | ⚠ ENDING IN " & daysLeft.ToString() & "D"
                lblValidity.ForeColor = Color.DarkOrange
            Else
                lblValidity.Text = "TRIAL | " & seatsShort & " | " & daysLeft.ToString() & "D LEFT"
                lblValidity.ForeColor = Color.Green
            End If
        Else
            If daysLeft <= EXPIRY_CRITICAL_DAYS Then
                lblValidity.Text = tierName & " | " & seatsShort & " | ⛔ EXPIRING IN " & daysLeft.ToString() & "D"
                lblValidity.ForeColor = Color.Red
            ElseIf daysLeft <= EXPIRY_WARNING_DAYS Then
                lblValidity.Text = tierName & " | " & seatsShort & " | ⚠ EXPIRING IN " & daysLeft.ToString() & "D"
                lblValidity.ForeColor = Color.DarkOrange
            Else
                lblValidity.Text = tierName & " | " & seatsShort & " | " & daysLeft.ToString() & "D LEFT"
                lblValidity.ForeColor = Color.Green
            End If
        End If
    End Sub

    Private Function GetTierNameSafe(tier As Integer) As String
        Select Case tier
            Case 0 : Return "TRIAL"
            Case 1 : Return "STANDARD"
            Case 2 : Return "PREMIUM"
            Case 3 : Return "PREMIUM PLUS"
            Case Else : Return "UNKNOWN"
        End Select
    End Function

    Private Sub ShowLicensePopup(sender As Object, e As EventArgs)
        MessageBox.Show(lblLicence.Text & vbCrLf & lblValidity.Text, "License Status", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    '========================================================
    ' THEME
    '========================================================
    Private Sub ShowThemeMenu(sender As Object, e As EventArgs)
        Dim m As New ContextMenuStrip()
        m.Items.Add("Light", Nothing, Sub() SetTheme(ThemeMode.PANEL_LIGHT))
        m.Items.Add("Dark", Nothing, Sub() SetTheme(ThemeMode.PANEL_DARK))
        m.Items.Add("MetaMech", Nothing, Sub() SetTheme(ThemeMode.PANEL_MM))
        m.Items.Add("Custom…", Nothing, Sub() PickCustomTheme())
        m.Show(btnTheme, New Point(0, btnTheme.Height))
    End Sub

    Private Sub PickCustomTheme()
        Using d As New ColorDialog()
            If d.ShowDialog() = DialogResult.OK Then
                customAccent = d.Color
                SetTheme(ThemeMode.PANEL_CUSTOM)
            End If
        End Using
    End Sub

    Private Sub SetTheme(m As ThemeMode)
        currentTheme = m
        ApplyTheme()
    End Sub

    Private Sub ApplyTheme()
        Select Case currentTheme
            Case ThemeMode.PANEL_LIGHT
                Me.BackColor = BG_LIGHT
                pnlHeader.BackColor = PANEL_LIGHT
                currentThemeIsDark = False

            Case ThemeMode.PANEL_DARK
                Me.BackColor = BG_DARK
                pnlHeader.BackColor = PANEL_DARK
                currentThemeIsDark = True

            Case ThemeMode.PANEL_MM
                Me.BackColor = BG_MM
                pnlHeader.BackColor = PANEL_MM
                currentThemeIsDark = False

            Case ThemeMode.PANEL_CUSTOM
                Me.BackColor = BG_LIGHT
                pnlHeader.BackColor = PANEL_LIGHT
                currentThemeIsDark = False
        End Select

        pnlHeaderLine.BackColor = customAccent

        Try
            If licenseValid Then
                lblLicence.ForeColor = If(currentThemeIsDark, Color.White, Color.Black)
            End If
        Catch
        End Try
    End Sub

    '========================================================
    ' HYBRID SEAT ENFORCEMENT
    '========================================================
    Private Function EnsureSeatForAction() As Boolean
        If Not licenseValid OrElse activeLicense Is Nothing OrElse Not activeLicense.IsValid Then
            LogA("⛔", "License invalid. Please activate a valid license.")
            Return False
        End If

        Try
            If activeLicense.ExpiryUtc <= DateTime.UtcNow Then
                LogA("⛔", "License expired. Please renew your license.")
                Return False
            End If
        Catch
            LogA("⛔", "License expiry check failed. Please re-activate your license.")
            Return False
        End Try

        Dim licenseId As String = GetLicenseIdSafe(activeLicense)
        If licenseId Is Nothing OrElse licenseId.Trim().Length = 0 Then
            LogA("❌", "Seat check failed: License ID not found in license payload.")
            Return False
        End If

        Dim tier As Integer = 0
        Dim seatsMax As Integer = 1

        Try
            tier = activeLicense.Tier
        Catch
            tier = currentTier
        End Try

        Try
            seatsMax = activeLicense.Seats
            If seatsMax <= 0 Then seatsMax = 1
        Catch
            seatsMax = 1
        End Try

        Try
            SeatEnforcer.EnsureSeatOrThrow(licenseId.Trim(), tier, seatsMax)
            Return True
        Catch ex As Exception
            LogA("⛔", "Seat enforcement blocked this action.")
            LogA("🧾", ex.Message)
            MessageBox.Show(ex.Message, "MDAT Seat Enforcement", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End Try
    End Function

    Private Function GetLicenseIdSafe(lic As LicenseInfo) As String
        If lic Is Nothing Then Return ""

        Try
            Dim t As Type = lic.GetType()

            Dim names() As String = New String() {"LicenseId", "LICENSEID", "LicenseID", "licenseId", "Id", "ID"}
            For i As Integer = 0 To names.Length - 1
                Dim p As PropertyInfo = t.GetProperty(names(i), BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.IgnoreCase)
                If p IsNot Nothing Then
                    Dim v As Object = p.GetValue(lic, Nothing)
                    If v IsNot Nothing Then
                        Dim s As String = Convert.ToString(v)
                        If s IsNot Nothing Then
                            s = s.Trim()
                            If s.Length > 0 Then Return s
                        End If
                    End If
                End If
            Next

            For i As Integer = 0 To names.Length - 1
                Dim f As FieldInfo = t.GetField(names(i), BindingFlags.Public Or BindingFlags.NonPublic Or BindingFlags.Instance Or BindingFlags.IgnoreCase)
                If f IsNot Nothing Then
                    Dim v As Object = f.GetValue(lic)
                    If v IsNot Nothing Then
                        Dim s As String = Convert.ToString(v)
                        If s IsNot Nothing Then
                            s = s.Trim()
                            If s.Length > 0 Then Return s
                        End If
                    End If
                End If
            Next
        Catch
        End Try

        Return ""
    End Function

    '========================================================
    ' CONFIG LOAD (seat + telemetry + macro delivery)
    '========================================================
    Private Sub LoadSeatConfigFromConfig()
        Try
            Dim cfgPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, CONFIG_FILE)
            If Not File.Exists(cfgPath) Then Exit Sub

            Dim seatServer As String = ""
            Dim seatToken As String = ""

            Dim localSyncUrl As String = ""
            Dim localMacroUrl As String = ""
            Dim localMacroToken As String = ""
            Dim localMacroCacheDir As String = ""
            Dim localHideCache As String = ""
            Dim localAutoClean As String = ""
            Dim localTelemetry As String = ""

            For Each rawLine As String In File.ReadAllLines(cfgPath)
                Dim line As String = rawLine.Trim()
                If line = "" OrElse line.StartsWith("#") OrElse line.StartsWith("[") Then Continue For

                Dim eq As Integer = line.IndexOf("="c)
                If eq <= 0 Then Continue For

                Dim k As String = line.Substring(0, eq).Trim().ToUpperInvariant()
                k = k.Replace(ChrW(&HFEFF), "")
                Dim v As String = line.Substring(eq + 1).Trim()

                If k = "SEAT_SERVER" Then
                    seatServer = v
                ElseIf k = "SEAT_TOKEN" Then
                    seatToken = v
                ElseIf k = "CLIENT_TOKEN" Then
                    If seatToken = "" Then seatToken = v
                ElseIf k = "SYNC_URL" Then
                    localSyncUrl = v
                ElseIf k = "MACRO_DELIVERY_URL" Then
                    localMacroUrl = v
                ElseIf k = "MACRO_TOKEN" Then
                    localMacroToken = v
                ElseIf k = "MACRO_CACHE_DIR" Then
                    localMacroCacheDir = v
                ElseIf k = "HIDE_MACRO_CACHE" Then
                    localHideCache = v
                ElseIf k = "AUTO_CLEAN_MACRO_CACHE" Then
                    localAutoClean = v
                ElseIf k = "TELEMETRY" Then
                    localTelemetry = v
                End If
            Next

            If localTelemetry <> "" Then
                Dim t As String = localTelemetry.Trim().ToUpperInvariant()
                telemetryEnabled = Not (t = "0" OrElse t = "FALSE" OrElse t = "NO" OrElse t = "OFF")
            End If

            If seatServer <> "" Then
                Try
                    SeatServerClient.ServerBaseUrl = seatServer
                    LogA("🔗", "Seat server loaded from config.")
                Catch
                End Try
            End If

            If seatToken <> "" Then
                Try
                    SeatServerClient.ClientToken = seatToken
                    LogA("🔐", "Client token loaded from config.")
                Catch
                End Try
                telemetryToken = seatToken
            End If

            If localSyncUrl <> "" Then syncUrl = localSyncUrl

            If localMacroUrl <> "" Then macroDeliveryUrl = localMacroUrl.Trim()
            If localMacroToken <> "" Then macroToken = localMacroToken.Trim()
            If localMacroCacheDir <> "" Then macroCacheDir = localMacroCacheDir.Trim()

            If localHideCache <> "" Then
                Dim t As String = localHideCache.Trim().ToUpperInvariant()
                hideMacroCache = (t = "1" OrElse t = "TRUE" OrElse t = "YES" OrElse t = "ON")
            End If

            If localAutoClean <> "" Then
                Dim t As String = localAutoClean.Trim().ToUpperInvariant()
                autoCleanMacroCacheAfterSuccess = (t = "1" OrElse t = "TRUE" OrElse t = "YES" OrElse t = "ON")
            End If
        Catch
        End Try
    End Sub

    '========================================================
    ' MACRO DELIVERY HELPERS
    '========================================================
    Private Sub EnsureTls12()
        Try
            ServicePointManager.SecurityProtocol = CType(3072, SecurityProtocolType)
        Catch
        End Try
    End Sub

    Private Function EnsureMacroCacheFolder() As Boolean
        Try
            Dim baseDirRaw As String = AppDomain.CurrentDomain.BaseDirectory
            Dim baseDir As String = baseDirRaw
            Try
                baseDir = baseDir.TrimEnd("\"c)
            Catch
            End Try

            Dim baseName As String = ""
            Try
                baseName = Path.GetFileName(baseDir).ToLowerInvariant()
            Catch
                baseName = ""
            End Try

            If macroCacheDir Is Nothing OrElse macroCacheDir.Trim() = "" Then
                If baseName = "output" Then
                    macroCacheDir = Path.Combine(baseDirRaw, "macros")
                Else
                    macroCacheDir = Path.Combine(baseDirRaw, "output\macros")
                End If
            Else
                Dim p As String = macroCacheDir.Trim()

                If Not Path.IsPathRooted(p) Then
                    If baseName = "output" Then
                        If p.ToLowerInvariant().StartsWith("output\") Then
                            p = p.Substring(7)
                        End If
                    End If
                    macroCacheDir = Path.Combine(baseDirRaw, p)
                Else
                    macroCacheDir = p
                End If
            End If

            If Not Directory.Exists(macroCacheDir) Then
                Directory.CreateDirectory(macroCacheDir)
            End If

            If hideMacroCache Then
                Try
                    Dim attr As FileAttributes = File.GetAttributes(macroCacheDir)
                    If (attr And FileAttributes.Hidden) = 0 Then
                        File.SetAttributes(macroCacheDir, attr Or FileAttributes.Hidden)
                    End If
                Catch
                End Try
            End If

            Return True
        Catch
            Return False
        End Try
    End Function

    Private Function EnsureMacroAvailable(originalPathOrKey As String, ByRef cachedLocalPath As String) As Boolean
        cachedLocalPath = ""

        Try
            If String.IsNullOrEmpty(originalPathOrKey) Then Return False

            If File.Exists(originalPathOrKey) Then
                cachedLocalPath = originalPathOrKey
                Return True
            End If

            If macroDeliveryUrl Is Nothing OrElse macroDeliveryUrl.Trim() = "" Then Return False
            If macroToken Is Nothing OrElse macroToken.Trim() = "" Then Return False

            If Not EnsureMacroCacheFolder() Then Return False

            Dim key As String = originalPathOrKey.Trim()
            Try
                If key.Contains("\") OrElse key.Contains("/") Then
                    key = Path.GetFileName(key)
                End If
            Catch
            End Try

            If key = "" Then Return False

            Dim dest As String = Path.Combine(macroCacheDir, key)
            If File.Exists(dest) Then
                cachedLocalPath = dest
                Return True
            End If

            EnsureTls12()

            Dim baseUrl As String = macroDeliveryUrl.Trim().TrimEnd("/"c)
            Dim url As String = baseUrl & "/api/v1/macro?key=" & Uri.EscapeDataString(key)

            LogA("☁️", "Fetching tool from server: " & key)

            Dim req As HttpWebRequest = CType(WebRequest.Create(url), HttpWebRequest)
            req.Method = "GET"
            req.UserAgent = "MDAT-MacroDelivery/1.0"
            req.Timeout = 20000
            req.ReadWriteTimeout = 20000
            req.Headers(HttpRequestHeader.Authorization) = "Bearer " & macroToken.Trim()

            Dim resp As HttpWebResponse = Nothing
            Try
                resp = CType(req.GetResponse(), HttpWebResponse)
            Catch ex As WebException
                Dim code As Integer = 0
                Try
                    If ex.Response IsNot Nothing Then
                        Dim r As HttpWebResponse = TryCast(ex.Response, HttpWebResponse)
                        If r IsNot Nothing Then code = CInt(r.StatusCode)
                    End If
                Catch
                End Try

                LogA("❌", "Macro fetch failed (" & code.ToString() & "): " & key)
                Return False
            End Try

            If resp Is Nothing Then
                LogA("❌", "Macro fetch failed: no response")
                Return False
            End If

            If resp.StatusCode <> HttpStatusCode.OK Then
                LogA("❌", "Macro fetch failed: HTTP " & CInt(resp.StatusCode).ToString())
                Try
                    resp.Close()
                Catch
                End Try
                Return False
            End If

            Try
                Using rs As Stream = resp.GetResponseStream()
                    Using fs As New FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.Read)
                        Dim buf(8191) As Byte
                        While True
                            Dim n As Integer = rs.Read(buf, 0, buf.Length)
                            If n <= 0 Then Exit While
                            fs.Write(buf, 0, n)
                        End While
                    End Using
                End Using
            Finally
                Try
                    resp.Close()
                Catch
                End Try
            End Try

            If File.Exists(dest) Then
                cachedLocalPath = dest
                LogA("✅", "Tool cached: " & key)
                Return True
            End If

            Return False

        Catch ex As Exception
            LogA("❌", "Macro fetch error: " & ex.Message)
            Return False
        End Try
    End Function

    '========================================================
    ' TELEMETRY HELPERS
    '========================================================
    Private Sub SendTelemetrySafe(status As String, slot As Integer, actionName As String, durationMs As Integer, logText As String)
        Try
            If Not telemetryEnabled Then Exit Sub
            If syncUrl Is Nothing OrElse syncUrl.Trim() = "" Then Exit Sub
            If telemetryToken Is Nothing OrElse telemetryToken.Trim() = "" Then Exit Sub

            Dim exeVersion As String = GetExeVersionSafe()

            Dim licenseId As String = ""
            Try
                licenseId = GetLicenseIdSafe(activeLicense)
            Catch
                licenseId = ""
            End Try

            Dim machineId As String = ""
            Try
                machineId = Environment.MachineName
            Catch
                machineId = ""
            End Try

            TelemetryService.SendEvent(syncUrl, telemetryToken, status, slot, actionName, exeVersion, licenseId, machineId, durationMs, logText)
        Catch
        End Try
    End Sub

    Private Function GetExeVersionSafe() As String
        Try
            Dim v As Version = Assembly.GetExecutingAssembly().GetName().Version
            If v IsNot Nothing Then Return v.ToString()
        Catch
        End Try
        Return "1.0"
    End Function

    Private Function GetAssemblyNameSafe() As String
        Try
            If selectedAssemblyPath Is Nothing Then Return ""
            Dim p As String = selectedAssemblyPath.Trim()
            If p = "" Then Return ""
            Return Path.GetFileName(p)
        Catch
            Return ""
        End Try
    End Function

    '========================================================
    ' LOG (Option A)
    '========================================================
    Private Sub Log(msg As String)
        If txtLog Is Nothing Then Return
        txtLog.AppendText(DateTime.Now.ToString("HH:mm:ss") & "  " & msg & vbCrLf)
    End Sub

    Private Sub LogA(icon As String, msg As String)
        If String.IsNullOrEmpty(icon) Then
            Log(msg)
        Else
            Log(icon & " " & msg)
        End If
    End Sub

End Class
